import Navbar from "../components/Navbar";
import Footer from "../components/Footer";

export default function Home() {
  return (
    <>
      <Navbar />
      <section style={{ padding: "100px", textAlign: "center" }}>
        <h1>MyndMesh Technologies</h1>
        <p>AI-Powered SaaS Ecosystem</p>
        <a href="/pricing">View Pricing</a>
      </section>
      <Footer />
    </>
  );
}