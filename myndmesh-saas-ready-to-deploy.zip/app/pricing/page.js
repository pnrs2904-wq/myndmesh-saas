"use client";

export default function Pricing() {

  const handlePayment = async () => {
    const res = await fetch("/api/checkout", { method: "POST" });
    const data = await res.json();
    window.location.href = data.url;
  };

  return (
    <div style={{ padding: "50px" }}>
      <h1>Pricing</h1>
      <button onClick={handlePayment}>
        Subscribe ₹1999
      </button>
    </div>
  );
}