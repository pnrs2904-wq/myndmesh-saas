import Stripe from "stripe";

export async function POST() {
  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

  const session = await stripe.checkout.sessions.create({
    payment_method_types: ["card"],
    line_items: [{
      price_data: {
        currency: "inr",
        product_data: { name: "MyndMesh SaaS Plan" },
        unit_amount: 199900,
      },
      quantity: 1,
    }],
    mode: "payment",
    success_url: process.env.NEXT_PUBLIC_BASE_URL,
    cancel_url: process.env.NEXT_PUBLIC_BASE_URL,
  });

  return Response.json({ url: session.url });
}