import DashboardCard from "../../components/DashboardCard";

export default function Dashboard() {
  return (
    <div style={{ padding: "50px" }}>
      <h1>Dashboard</h1>
      <div style={{ display: "flex", gap: "20px" }}>
        <DashboardCard title="Users" value="5234" />
        <DashboardCard title="MRR" value="₹1 Cr" />
        <DashboardCard title="ARR" value="₹12 Cr" />
      </div>
    </div>
  );
}