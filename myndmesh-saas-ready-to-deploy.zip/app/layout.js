import "../styles/globals.css";

export const metadata = {
  title: "MyndMesh SaaS",
};

export default function RootLayout({ children }) {
  return (
    <html>
      <body>{children}</body>
    </html>
  );
}