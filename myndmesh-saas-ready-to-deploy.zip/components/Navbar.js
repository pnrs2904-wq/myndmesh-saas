export default function Navbar() {
  return (
    <nav style={{ padding: "20px", background: "#0F172A", color: "white" }}>
      <h2>MyndMesh</h2>
    </nav>
  );
}