export default function Footer() {
  return (
    <footer style={{ padding: "50px", textAlign: "center" }}>
      <p>© {new Date().getFullYear()} MYNDMESH TECHNOLOGIES</p>
      <p>Founders: SHIRISH BAYYANNAGARI & RAJ PATARLAPATI</p>
      <p>Email: myndmeshtechnologies@gmail.com</p>
    </footer>
  );
}